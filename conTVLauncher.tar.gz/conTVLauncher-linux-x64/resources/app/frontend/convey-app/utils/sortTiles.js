module.exports =  {
    sort: function() {
        return 'Hola';
    }
};