class uiAccordion extends Polymer.Element {
    static get is() { return 'ui-accordion'; }
    static get properties() {
        return {
        };
    }

}

window.customElements.define(uiAccordion.is, uiAccordion);