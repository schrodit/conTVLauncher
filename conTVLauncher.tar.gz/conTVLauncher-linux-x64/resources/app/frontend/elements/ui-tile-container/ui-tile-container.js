class uiTileContainer extends Polymer.Element {
    static get is() { return 'ui-tile-container'; }
    static get properties() {
        return {
        };
    }
}

window.customElements.define(uiTileContainer.is, uiTileContainer);